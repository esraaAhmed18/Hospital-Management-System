-- Insert Departments
INSERT INTO Department VALUES (seq_dept_id.NEXTVAL, 'Cardiology', 'Building A - Floor 2');
INSERT INTO Department VALUES (seq_dept_id.NEXTVAL, 'Pediatrics', 'Building B - Floor 1');
INSERT INTO Department VALUES (seq_dept_id.NEXTVAL, 'Orthopedics', 'Building A - Floor 3');

-- Insert Doctors
INSERT INTO Doctor VALUES (seq_doctor_id.NEXTVAL, 'Ahmed', 'Ali', 'Cardiologist', '0501234567', 10);
INSERT INTO Doctor VALUES (seq_doctor_id.NEXTVAL, 'Fatima', 'Omar', 'Pediatrician', '0559876543', 20);
INSERT INTO Doctor VALUES (seq_doctor_id.NEXTVAL, 'Khaled', 'Ibrahim', 'Orthopedic Surgeon', '0541112233', 30);

-- Insert Patients
INSERT INTO Patient VALUES (seq_patient_id.NEXTVAL, 'Sara', 'Mohammed', 'Female', TO_DATE('1995-05-12', 'YYYY-MM-DD'), '0567778899', 'Riyadh');
INSERT INTO Patient VALUES (seq_patient_id.NEXTVAL, 'Saeed', 'Abdullah', 'Male', TO_DATE('1988-10-20', 'YYYY-MM-DD'), '0503334455', 'Jeddah');

-- Insert Appointments
INSERT INTO Appointment VALUES (seq_appointment_id.NEXTVAL, 1000, 500, SYSDATE + 1, 'Scheduled');
INSERT INTO Appointment VALUES (seq_appointment_id.NEXTVAL, 1001, 502, SYSDATE + 2, 'Scheduled');

-- Insert Billing
INSERT INTO Billing VALUES (seq_billing_id.NEXTVAL, 5000, 350.00, 'Unpaid', NULL);
INSERT INTO Billing VALUES (seq_billing_id.NEXTVAL, 5001, 500.00, 'Paid', SYSDATE);

COMMIT;
