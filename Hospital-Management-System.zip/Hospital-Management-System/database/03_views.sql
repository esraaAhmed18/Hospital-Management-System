-- View 1: Detailed Appointment View
CREATE OR REPLACE VIEW vw_appointment_details AS
SELECT 
    a.Appointment_ID,
    p.First_Name || ' ' || p.Last_Name AS Patient_Name,
    d.First_Name || ' ' || d.Last_Name AS Doctor_Name,
    dept.Department_Name,
    a.Appointment_Date,
    a.Status
FROM Appointment a
JOIN Patient p ON a.Patient_ID = p.Patient_ID
JOIN Doctor d ON a.Doctor_ID = d.Doctor_ID
JOIN Department dept ON d.Department_ID = dept.Department_ID;

-- View 2: Financial Summary View
CREATE OR REPLACE VIEW vw_financial_summary AS
SELECT 
    b.Bill_ID,
    p.First_Name || ' ' || p.Last_Name AS Patient_Name,
    b.Total_Amount,
    b.Payment_Status,
    b.Payment_Date
FROM Billing b
JOIN Appointment a ON b.Appointment_ID = a.Appointment_ID
JOIN Patient p ON a.Patient_ID = p.Patient_ID;
