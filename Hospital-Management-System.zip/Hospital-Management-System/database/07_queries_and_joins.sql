-- Query 1: Doctor Appointments Count (JOIN & GROUP BY)
SELECT 
    d.Doctor_ID,
    d.First_Name || ' ' || d.Last_Name AS Doctor_Name,
    dept.Department_Name,
    COUNT(a.Appointment_ID) AS Total_Appointments
FROM Doctor d
JOIN Department dept ON d.Department_ID = dept.Department_ID
LEFT JOIN Appointment a ON d.Doctor_ID = a.Doctor_ID
GROUP BY d.Doctor_ID, d.First_Name, d.Last_Name, dept.Department_Name;

-- Query 2: Patients with Cardiology Appointments (Subquery & JOIN)
SELECT First_Name, Last_Name, Phone
FROM Patient
WHERE Patient_ID IN (
    SELECT a.Patient_ID
    FROM Appointment a
    JOIN Doctor d ON a.Doctor_ID = d.Doctor_ID
    WHERE d.Specialization = 'Cardiologist'
);

-- Query 3: Patients with Billing Above Average (Aggregate Subquery)
SELECT p.First_Name, p.Last_Name, b.Total_Amount
FROM Patient p
JOIN Appointment a ON p.Patient_ID = a.Patient_ID
JOIN Billing b ON a.Appointment_ID = b.Appointment_ID
WHERE b.Total_Amount > (SELECT AVG(Total_Amount) FROM Billing);
