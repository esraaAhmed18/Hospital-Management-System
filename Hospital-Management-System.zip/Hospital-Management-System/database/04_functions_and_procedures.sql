-- Function: Calculate Revenue by Payment Status
CREATE OR REPLACE FUNCTION get_total_revenue(p_status IN VARCHAR2) 
RETURN NUMBER IS
    v_total NUMBER(10, 2);
BEGIN
    SELECT SUM(Total_Amount) INTO v_total
    FROM Billing
    WHERE Payment_Status = p_status;
    
    RETURN NVL(v_total, 0);
END;
/

-- Procedure: Update Payment Status and Payment Date
CREATE OR REPLACE PROCEDURE update_payment_status (
    p_bill_id IN INT,
    p_new_status IN VARCHAR2
) AS
BEGIN
    UPDATE Billing
    SET Payment_Status = p_new_status,
        Payment_Date = CASE WHEN p_new_status = 'Paid' THEN SYSDATE ELSE Payment_Date END
    WHERE Bill_ID = p_bill_id;
    
    COMMIT;
END;
/
