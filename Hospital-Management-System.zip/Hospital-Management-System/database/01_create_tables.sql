-- 1. Create Sequences
CREATE SEQUENCE seq_patient_id START WITH 1000 INCREMENT BY 1;
CREATE SEQUENCE seq_doctor_id START WITH 500 INCREMENT BY 1;
CREATE SEQUENCE seq_dept_id START WITH 10 INCREMENT BY 10;
CREATE SEQUENCE seq_appointment_id START WITH 5000 INCREMENT BY 1;
CREATE SEQUENCE seq_billing_id START WITH 7000 INCREMENT BY 1;

-- 2. Create Departments Table
CREATE TABLE Department (
    Department_ID INT PRIMARY KEY,
    Department_Name VARCHAR2(100) NOT NULL UNIQUE,
    Location VARCHAR2(100)
);

-- 3. Create Doctors Table
CREATE TABLE Doctor (
    Doctor_ID INT PRIMARY KEY,
    First_Name VARCHAR2(50) NOT NULL,
    Last_Name VARCHAR2(50) NOT NULL,
    Specialization VARCHAR2(100) NOT NULL,
    Phone VARCHAR2(20),
    Department_ID INT,
    CONSTRAINT fk_doc_dept FOREIGN KEY (Department_ID) REFERENCES Department(Department_ID)
);

-- 4. Create Patients Table
CREATE TABLE Patient (
    Patient_ID INT PRIMARY KEY,
    First_Name VARCHAR2(50) NOT NULL,
    Last_Name VARCHAR2(50) NOT NULL,
    Gender VARCHAR2(10) CHECK (Gender IN ('Male', 'Female')),
    Date_Of_Birth DATE,
    Phone VARCHAR2(20) UNIQUE,
    Address VARCHAR2(200)
);

-- 5. Create Appointments Table
CREATE TABLE Appointment (
    Appointment_ID INT PRIMARY KEY,
    Patient_ID INT NOT NULL,
    Doctor_ID INT NOT NULL,
    Appointment_Date DATE NOT NULL,
    Status VARCHAR2(20) DEFAULT 'Scheduled' CHECK (Status IN ('Scheduled', 'Completed', 'Cancelled')),
    CONSTRAINT fk_app_patient FOREIGN KEY (Patient_ID) REFERENCES Patient(Patient_ID),
    CONSTRAINT fk_app_doctor FOREIGN KEY (Doctor_ID) REFERENCES Doctor(Doctor_ID)
);

-- 6. Create Billing Table
CREATE TABLE Billing (
    Bill_ID INT PRIMARY KEY,
    Appointment_ID INT UNIQUE NOT NULL,
    Total_Amount NUMBER(10, 2) CHECK (Total_Amount >= 0),
    Payment_Status VARCHAR2(20) DEFAULT 'Unpaid' CHECK (Payment_Status IN ('Paid', 'Unpaid', 'Pending')),
    Payment_Date DATE,
    CONSTRAINT fk_bill_app FOREIGN KEY (Appointment_ID) REFERENCES Appointment(Appointment_ID)
);

-- 7. Create Audit Log Table (for Triggers)
CREATE TABLE Patient_Audit_Log (
    Log_ID INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    Patient_ID INT,
    Action_Type VARCHAR2(50),
    Change_Date DATE DEFAULT SYSDATE
);

-- Indexes for performance optimization
CREATE INDEX idx_patient_name ON Patient(Last_Name, First_Name);
CREATE INDEX idx_appointment_date ON Appointment(Appointment_Date);
