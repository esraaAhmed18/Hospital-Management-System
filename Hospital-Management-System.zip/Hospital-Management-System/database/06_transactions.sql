-- Safe Transaction with Savepoint, Commit & Rollback
SAVEPOINT Before_Delete;

-- Update Patient Info
UPDATE Patient
SET Phone = '0559999999'
WHERE Patient_ID = 1001;

-- Delete Billing Record
DELETE FROM Billing
WHERE Bill_ID = 7004;

-- If any issue occurs, rollback to savepoint
-- ROLLBACK TO Before_Delete;

-- Confirm changes
COMMIT;
