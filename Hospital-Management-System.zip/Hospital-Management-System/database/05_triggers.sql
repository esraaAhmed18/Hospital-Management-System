-- Trigger 1: Prevent Scheduling Appointments in the Past
CREATE OR REPLACE TRIGGER trg_check_appointment_date
BEFORE INSERT ON Appointment
FOR EACH ROW
BEGIN
    IF :NEW.Appointment_Date < TRUNC(SYSDATE) THEN
        RAISE_APPLICATION_ERROR(-20001, 'Error: Cannot schedule an appointment in the past.');
    END IF;
END;
/

-- Trigger 2: Audit Patient Phone Updates
CREATE OR REPLACE TRIGGER trg_audit_patient_update
AFTER UPDATE OF Phone ON Patient
FOR EACH ROW
BEGIN
    INSERT INTO Patient_Audit_Log (Patient_ID, Action_Type, Change_Date)
    VALUES (:OLD.Patient_ID, 'UPDATED_PHONE', SYSDATE);
END;
/
